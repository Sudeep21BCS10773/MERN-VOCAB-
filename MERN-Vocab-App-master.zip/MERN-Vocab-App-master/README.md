# MERN-Vocab-App

### [Live Site](https://mernvocabularykhatrironitapp.herokuapp.com/)

To Run the project:
  1. Clone this repo.
  2. Go to frontend directory:
  ```js
          npm install
          npm start
  ```
  3. Go to backend directory:
  ```js
          npm install
          node start
  ```